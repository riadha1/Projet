#ifndef FONCTIONS_H_
#define FONCTIONS_H_

void initLevel(int n);
void Level1(int n);
void Level2();
void Level3();

#endif
